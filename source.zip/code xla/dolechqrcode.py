import cv2
import numpy as np

def angle_between_points(point, point1, point2):
   
    vector1 = np.array([point1[0] - point[0], point1[1] - point[1]])
    vector2 = np.array([point2[0] - point[0], point2[1] - point[1]])

    
    norm1 = np.linalg.norm(vector1)
    norm2 = np.linalg.norm(vector2)

    
    if norm1 == 0 or norm2 == 0:
        return 0

    
    dot_product = np.dot(vector1, vector2)
    angle_radians = np.arccos(np.clip(dot_product / (norm1 * norm2), -1.0, 1.0))

    
    angle_degrees = np.degrees(angle_radians)
    return angle_degrees
def classify_product(qr_code_data):
    if qr_code_data:
        print("Phân loại sản phẩm dựa trên thông tin từ mã QR code:", qr_code_data)

def draw_dot_on_camera():
    cap = cv2.VideoCapture(2) 
    cap.set(cv2.CAP_PROP_FPS, 10)
    cap.set(3, 640)
    cap.set(4, 480)

    while True:
        ret, frame = cap.read()
        frame = cv2.flip(frame, 1)
        center_x = 0
        center_y = 0

        if ret:
            
            detector = cv2.QRCodeDetector()    
            data, bbox, _ = detector.detectAndDecode(frame)
            
           
            center_point = (358,298)
            center_point1 = (186,409)
            center_point1_2 = (523, 396)    
            center_point1_3 = (346, 99)

            
            cv2.circle(frame, center_point, radius=5, color=(0, 255, 0), thickness=-1)
            cv2.circle(frame, center_point1, radius=5, color=(0, 255, 0), thickness=-1)
            cv2.circle(frame, center_point1_2, radius=5, color=(0, 255, 0), thickness=-1)
            cv2.circle(frame, center_point1_3, radius=5, color=(0, 255, 0), thickness=-1)
            
            cv2.line(frame, center_point, center_point1, (0, 0, 255), 2)
            cv2.line(frame, center_point, center_point1_2, (0, 0, 255), 2)
            cv2.line(frame, center_point, center_point1_3, (0, 0, 255), 2)

            if data:
                classify_product(data)
                
                bbox = bbox[0]
                bbox = bbox.astype(int)
                
                
                top_left = tuple(bbox[0])
                top_right = tuple(bbox[1])
                bottom_right = tuple(bbox[2])
                bottom_left = tuple(bbox[3])

                
                cv2.circle(frame, top_left, radius=5, color=(0, 255, 0), thickness=-1)
                cv2.circle(frame, top_right, radius=5, color=(0, 255, 0), thickness=-1)
                cv2.circle(frame, bottom_right, radius=5, color=(0, 255, 0), thickness=-1)
                cv2.circle(frame, bottom_left, radius=5, color=(0, 255, 0), thickness=-1)

                
                cv2.polylines(frame, [bbox], True, (0, 255, 0), 2)
                
                # Tính tâm của mã QR code
                M = cv2.moments(bbox)
                if M["m00"] != 0:
                    center_x = int(M["m10"] / M["m00"])
                    center_y = int(M["m01"] / M["m00"])
                    # Vẽ tâm của mã QR code
                    cv2.circle(frame, (center_x, center_y), 5, (0, 0, 255), -1)
                    print("Tọa độ tâm:", center_x, center_y)
                    
                    
                    angle = angle_between_points(center_point, center_point1, (center_x, center_y))
                    angle1 = angle_between_points(center_point, center_point1_2, (center_x, center_y))
                    angle2 = angle_between_points(center_point, center_point1_3, (center_x, center_y))
                    vector3 = np.array([top_left[0] - bottom_left[0], top_left[1] - bottom_left[1]])
                    vector4 = np.array([center_point1_3[0] - center_point[0], center_point1_3[1] - center_point[1]])
                    angle3= angle_between_points((0,0), vector3, vector4)
    
                    min_angle = min(angle1, angle2, angle)
                    angle_string = "Angle: {:.2f}".format( angle3)
                    cv2.putText(frame, angle_string, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        cv2.imshow("frame", frame)
        key = cv2.waitKey(1)
        if key == ord("q"):
            break

    
    cap.release()
    cv2.destroyAllWindows()
draw_dot_on_camera()

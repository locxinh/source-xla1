import cv2
import numpy as np

def angle_between_points(point, point1, point2):
    # Tính vector từ point đến point1 và từ point đến point2
    vector1 = np.array([point1[0] - point[0], point1[1] - point[1]])
    vector2 = np.array([point2[0] - point[0], point2[1] - point[1]])

    # Tính độ dài của các vector
    norm1 = np.linalg.norm(vector1)
    norm2 = np.linalg.norm(vector2)

    # Tính góc lệch bằng arccos của dot product giữa hai vector
    dot_product = np.dot(vector1, vector2)
    angle_radians = np.arccos(dot_product / (norm1 * norm2))

    # Chuyển đổi từ radian sang độ
    angle_degrees = np.degrees(angle_radians)
    return angle_degrees

def draw_dot_on_camera():
    cap = cv2.VideoCapture(0)
    cap.set(3, 640)
    cap.set(4, 480)

    while True:
        ret, frame = cap.read()
        frame = cv2.flip(frame, 1)
        if not ret:
            break

        # Tọa độ của các điểm
        center_point = (int(frame.shape[1] / 2), int(frame.shape[0] / 2))
        center_point1 = (80, 385)
        center_point1_2 = (540, 385)
        center_point1_3 = (313, 50)
        center_point2 = (453, 390)

        # Vẽ chấm trên frame
        cv2.circle(frame, center_point, radius=5, color=(0, 255, 0), thickness=-1)
        cv2.circle(frame, center_point1, radius=5, color=(0, 255, 0), thickness=-1)
        cv2.circle(frame, center_point1_2, radius=5, color=(0, 255, 0), thickness=-1)
        cv2.circle(frame, center_point1_3, radius=5, color=(0, 255, 0), thickness=-1)


        cv2.circle(frame, center_point2, radius=5, color=(0, 255, 0), thickness=-1)

        # Nối các điểm với nhau
        cv2.line(frame, center_point, center_point1, (0, 0, 255), 2)
        cv2.line(frame, center_point, center_point1_2, (0, 0, 255), 2)
        cv2.line(frame, center_point, center_point1_3, (0, 0, 255), 2)

        # Tính góc lệch giữa center_point2 và đường thẳng được tạo bởi center_point và center_point1
        angle = angle_between_points(center_point, center_point1, center_point2)
        angle1 = angle_between_points(center_point, center_point1_2, center_point2)
        angle2 = angle_between_points(center_point, center_point1_3, center_point2)
        # Tìm góc nhỏ nhất
        min_angle = min(angle1, angle2, angle)




        cv2.putText(frame, "Min Angle: {:.2f}".format(min_angle), (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Hiển thị frame với chấm trên màn hình
        cv2.imshow("Camera", frame)

        # Thoát khỏi vòng lặp nếu nhấn phím 'q'
        if cv2.waitKey(1) == ord('q'):
            break

    # Giải phóng tài nguyên
    cap.release()
    cv2.destroyAllWindows()

# Gọi hàm để vẽ chấm trên màn hình của camera
draw_dot_on_camera()
